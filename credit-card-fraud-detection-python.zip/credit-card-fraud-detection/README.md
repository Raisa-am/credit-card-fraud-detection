# Credit Card Fraud Detection (Python)

A beginner-friendly machine-learning project that compares Logistic Regression and Random Forest for an imbalanced binary classification task.

## Important note about the data

This repository runs immediately using **synthetic demonstration data** if `creditcard.csv` is not present. Synthetic data is simulated and must not be described as real transaction data or used to claim real-world model performance.

To run it on the commonly used Kaggle Credit Card Fraud Detection dataset, download `creditcard.csv` from Kaggle and place it beside `fraud_detection.py`. The file should contain a `Class` column (`0` = legitimate, `1` = fraud). Do not upload datasets if their licence or terms do not permit redistribution.

## Project contents

- `fraud_detection.py` — data loading, preprocessing, model training and evaluation.
- `requirements.txt` — Python dependencies.
- `outputs/` — generated charts and model comparison CSV (created after running).

## Run locally

```bash
pip install -r requirements.txt
python fraud_detection.py
```

## Workflow

1. Load the Kaggle CSV if available; otherwise create a synthetic demo dataset.
2. Check the class distribution and prepare numeric features.
3. Split the data into training and test sets using stratification.
4. Standardize features.
5. Train Logistic Regression and Random Forest with class weighting to address class imbalance.
6. Compare fraud-class precision, recall, F1-score, ROC-AUC and average precision.
7. Save confusion matrices, a class-distribution chart and a model-comparison CSV in `outputs/`.

## Evaluation

For fraud detection, accuracy alone can be misleading because fraud cases are rare. Review precision and recall together, along with F1-score, ROC-AUC, average precision and the confusion matrix.

## Limitations

This is an educational baseline, not a production fraud-detection system. Threshold tuning, temporal validation, leakage checks, explainability, and monitoring would be needed before any real deployment.
